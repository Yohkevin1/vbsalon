// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('.dataTable').DataTable();
});

// $(document).ready(function () {
//     $('#tableLaporan_PJL').DataTable({
//         "searching": false, 
//     });
// });

// $(document).ready(function () {
//     $('#tableLaporan_PBL').DataTable({
//         "searching": false, 
//     });
// });
