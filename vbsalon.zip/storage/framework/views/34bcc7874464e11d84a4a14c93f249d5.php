
<?php $__env->startSection('title'); ?>
VB Salon | Edit Transaksi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('judul'); ?>
Edit Transaksi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row" style="color: black">
    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <label class="col-form-label">Tanggal</label>
                        <input type="text" value="<?= date('d/m/y') ?>" disabled class="form-control">
                        <input type="hidden" id="id" value="<?php echo e($pjl->no_penjualan); ?>" disabled class="form-control">
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <label class="col-form-label">Pegawai</label>
                        <input class="form-control" type="text" id="nama" value="<?php echo e($pjl->pegawai->nama); ?>" disabled>
                        <input class="form-control" type="hidden" id="no_pegawai" value="<?php echo e($pjl->pegawai->no_pegawai); ?>">
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <label class="col-form-label">Telp Pelanggan:</label>
                        <input type="text" id="telp_pel" class="form-control" value="<?php echo e($pjl->telp_pelanggan); ?>" disabled>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <button class="btn btn-primary" data-bs-target="#Produk" data-bs-toggle="modal">Pilih Produk</button>
                        <button class="btn btn-info" data-bs-target="#Jasa" data-bs-toggle="modal">Pilih Jasa</button>
                        <button class="btn btn-dark" data-bs-target="#Pegawai" data-bs-toggle="modal">Pilih Pegawai</button>
                    </div>
                </div>
                <table class="table table-striped table-hover table-responsive mt-4" style="color: black">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Foto</th>
                            <th>Produk / Jasa</th>
                            <th>Jumlah</th>
                            <th>Satuan</th>
                            <th>Subtotal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="detail_cart">
                    </tbody>
                </table>
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <label class="col-form-label">Total bayar</label>
                        <h1><span id="spanTotal">0</span></h1>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="mb-3 row">
                            <label class="col-4 col-form-label">Nominal</label>
                            <div class="col-8">
                                <input type="text" class="form-control" id="nominal" value="<?php echo e(old('bayar', $pjl->bayar)); ?>" autocomplete="off">
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label class="col-4 col-form-label">Kembalian</label>
                            <div class="col-8">
                                <input type="text" class="form-control" id="kembalian" disabled>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-grid gap-3 d-md-flex justify-content-md-end">
                    <button onclick="bayar()" class="btn btn-success me-md-2" type="button">Proses Bayar</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('transaksi.modalProduk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('transaksi.modalJasa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('transaksi.modalPegawai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Modal Update Jumlah--->
<div class="modal fade" id="Ubah" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalToggleLabel">Data Produk</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Table Produk -->
                <div class="row mt-3">
                    <div class="col-sm-7">
                        <input type="hidden" id="id">
                        <input type="number" class="form-control" id="qty" placeholder="Masukkan jumlah produk" min="1" value="1">
                    </div>
                    <div class="col-sm-5">
                        <button class="btn btn-primary" onclick="update_cart()"> Simpan</button>
                    </div>
                </div>
                <!-- -->
            </div>
        </div>
    </div>
</div>

<script>
    function load() {
        $('#detail_cart').load("<?php echo e(route('loadCart')); ?>");
         $('#spanTotal').load("<?php echo e(route('getTotal')); ?>");
    }
    $(document).ready(function() {
        load();
    });

    $(document).on('click', '.hapus_cart', function() {
        var id = $(this).attr("id"); 
        $.ajax({
            url: "<?php echo e(url('removeCart', )); ?>/" + id,
            type: "DELETE",
            data: {
                id: id,
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function(data) {
                load();
            },
        });
    });

    $(document).on('click', '.ubah_cart', function() {
        var id = $(this).attr("id");
        var qty = $(this).attr("qty");
        $('#id').val(id);
        $('#qty').val(qty);
        $('#Ubah').modal('show');
    });

    function update_cart() {
        var id = $('#id').val();
        var qty = $('#qty').val();
        $.ajax({
            url: "<?php echo e(route('updateCart')); ?>",
            method: "POST",
            data: {
                id: id,
                qty: qty,
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function(data) {
                load();
                $('#Ubah').modal('hide');
            }
        });
    }

    function bayar() {
        var id = $('#id').val();
        var nominal = $('#nominal').val();
        var pegawai = $('#no_pegawai').val();
        var pelanggan = $('#telp_pel').val();
        $.ajax({
            url: "<?php echo e(route('updatePembayaran')); ?>",
            method: "POST",
            data: {
                'no_penjualan' : id,
                'nominal': nominal,
                'no_pegawai': pegawai,
                'telp_pel' : pelanggan,
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function(response) {
                var result = JSON.parse(response);
                swal({
                    title: result.msg,
                    icon: result.status ? "success" : "error",
                });
                // alert(result.msg);
                load();
                $('#nominal').val("");
                $('#kembalian').val(result.data.kembalian);
                setTimeout(function() {
                    window.history.back();
                }, 3500); //3500 = 3,5 detik
            }
        })
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 5\PADSI\PADSI_FIX\resources\views/transaksi/storeEditTransaksi.blade.php ENDPATH**/ ?>