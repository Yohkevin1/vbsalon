
<?php $__env->startSection('title'); ?>
Admin | Transaksi Pembelian
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="home-section">
    <div class="home-content px-1">
        <i class='bx bx-menu'></i>
        <span class="text">Transaksi Pembelian</span>
    </div>
    <div class="container-fluid px-4" style="margin-top: 27px">
        <div class="card mb-4">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <label class="col-form-label" style="padding-right: 5px">Tanggal: </label>
                        <input type="text" value="<?= date('D, j F Y') ?>" disabled>
                    </div>
                    <div class="col">
                        <label class="col-form-label">Username: </label>
                        <input type="text" value="<?= session('username') ?>" disabled>
                    </div>
                    <div class="col">
                        <label class="col-form-label" style="padding-right: 5px">Supplier: </label>
                        <input type="text" id="nama-cust" disabled>
                        <input type="hidden" id="id-cust">
                    </div>
                    <div class="col" style="line-height: 2.5rem">
                        <button class="btn btn-dark" data-bs-target="#Customer" data-bs-toggle="modal">Cari Supplier</button>
                    </div>
                </div>
                <table class="table table-striped table-hover mt-4">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Produk</th>
                            <th>Jumlah</th>
                            <th>Total</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="detail_cart">
                    </tbody>
                </table>
                <div class="col-12">
                    <div class="d-grip gap-3 d-md-felx justify-content-md-end">
                        <button class="btn btn-primary me-md-2" type="button" data-bs-target="#newTransaksi" data-bs-toggle="modal">Transaksi Baru</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- -->
    </div>
</section>


<div class="modal fade" id="newTransaksi" aria-hidden="true" aria-labelledby="newTransaksi" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="judul">Transaksi Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Form data -->
                     <form action="/komik-create" method="post" enctype="multipart/form-data">
                         <?= csrf_field() ?>
                         <div class="mb-3 row">
                             <label for="judul" class="col-sm-2 col-form-label">Judul Buku</label>
                             <div class="col-sm-10">
                                 
                             </div>
                         </div>
                         <div class="mb-3 row">
                             <label for="penulis" class="col-sm-2 col-form-label">Penulis</label>
                             <div class="col-sm-10">
                                 
                             </div>
                         </div>
                         <div class="mb-3 row">
                             <label for="tahun_rilis" class="col-sm-2 col-form-label">Tahun Rilis</label>
                             <div class="col-sm-5">
                                 
                             </div>
                             <label for="stock" class="col-sm-2 col-form-label">Stock</label>
                             <div class="col-sm-3">
                                 
                             </div>
                         </div>
                         <div class="mb-3 row">
                             <label for="harga" class="col-sm-2 col-form-label">Harga</label>
                             <div class="col-sm-5">
                                
                             </div>
                             <label for="diskon" class="col-sm-2 col-form-label">diskon</label>
                             <div class="col-sm-3">
                                 
                             </div>
                         </div>
                         <div class="mb-3 row">
                             <label for="cover" class="col-sm-2 col-form-label">Cover</label>
                             <div class="col-sm-5">
                                 
                                 <div class="col-sm-6 mt-2">
                                   
                                 </div>
                             </div>
                             <label for="id_kategori" class="col-sm-2 col-form-label">Kategori</label>
                             <div class="col-sm-3">
                                 
                             </div>
                         </div>
                     </form>
                     <!-- end form -->
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" data-bs-dismiss="modal">Simpan</button>
            </div>
        </div>
    </div>
</div>

<style>

</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 5\PADSI\PADSI_FIX\resources\views/pembelian/cartPembelian.blade.php ENDPATH**/ ?>