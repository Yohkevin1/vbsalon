
<?php $__env->startSection('title'); ?>
VB Salon | Transaksi Penjualan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('judul'); ?>
Transaksi Penjualan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="row">
    <div class="col-md-12">
        <div class="card mb-4" style="color: black">
            <div class="card-header">
                List Data Penjualan
            </div>
            <div class="card-body">
                <a href="<?php echo e(route('storeTransaksi')); ?>" class="btn btn-primary mb-3 btn-tambah"><i class="fas fa-plus-circle"></i> Tambah Transaksi</a>
                <table class="dataTable table table-hover table-responsive w-auto" style="color: black">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Melayani</th>
                            <th>Telp. Pelanggan</th>
                            <th>Total Harga</th>
                            <th>Pembayaran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $trs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($no++); ?></th>
                                <th style="width: 15%"><?php echo e($item->pegawai->nama); ?></th>
                                <th style="width: 23%"><?php echo e($item->telp_pelanggan); ?></th>
                                <th style="width: 20%">Rp <?php echo e(number_format($item->total_harga, 2, ',', '.')); ?></th>
                                <th style="width: 20%">Rp <?php echo e(number_format($item->bayar, 2, ',', '.')); ?></th>
                                <td style="width: 20%">
                                    <a class="btn btn-warning text-white" href="<?php echo e(route('editPagePJL', encrypt($item->no_penjualan))); ?>">
                                        <i class="fas fa-pen-to-square"></i> Ubah
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 5\PADSI\PADSI_FIX\resources\views/transaksi/indexTransaksi.blade.php ENDPATH**/ ?>