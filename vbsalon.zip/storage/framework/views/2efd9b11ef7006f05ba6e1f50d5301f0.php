
<?php $__env->startSection('title'); ?>
Admin | Transaksi Penjualan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="home-section">
    <div class="home-content px-1">
        <i class='bx bx-menu'></i>
        <span class="text">Transaksi Penjualan</span>
    </div>
    <div class="container-fluid px-4" style="margin-top: 27px">
        <div class="card mb-4">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <label class="col-form-label" style="padding-right: 5px">Tanggal: </label>
                        <input type="text" value="<?= date('D, j F Y') ?>" disabled>
                    </div>
                    <div class="col">
                        <label class="col-form-label">Username: </label>
                        <input type="text" value="<?= session('username') ?>" disabled>
                    </div>
                    <div class="col">
                        <label class="col-form-label">Customer: </label>
                        <input type="text" id="nama-cust" disabled>
                        <input type="hidden" id="id-cust">
                    </div>
                    <div class="col" style="line-height: 2.5rem">
                        <button class="btn btn-primary" data-bs-target="#Produk" data-bs-toggle="modal">Pilih Produk</button>
                        <button class="btn btn-dark" data-bs-target="#Customer" data-bs-toggle="modal">Cari customer</button>
                    </div>
                </div>
                <table class="table table-striped table-hover mt-4">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Produk</th>
                            <th>Jumlah</th>
                            <th>Harga Satuan</th>
                            <th>Diskon</th>
                            <th>Subtotal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="detail_cart">
                    </tbody>
                </table>
                <div class="col-12">
                    <div class="row" >
                        <div class="col-md-7 col-5">
                            <label class="col-form-label">Total bayar</label>
                            <h1><span id="spanTotal">0</span></h1>
                        </div>
                        <div class="col-md-5 col-7">
                            <div class="mb-3 row">
                                <label class="col-4 col-form-label">Nominal</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" id="nominal" autocomplete="off">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label class="col-4 col-form-label">Kembalian</label>
                                <div class="col-8">
                                    <input type="text" class="form-control" id="kembalian" disabled>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-grip gap-3 d-md-felx justify-content-md-end">
                        <button onclick="bayar()" class="btn btn-success me-md-2" type="button"> Proses Bayar</button>
                        <button onclick="location.reload()" class="btn btn-primary" type="button"> Transaksi Baru</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- -->
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 5\PADSI\PADSI_FIX\resources\views/penjualan/cartPenjualan.blade.php ENDPATH**/ ?>