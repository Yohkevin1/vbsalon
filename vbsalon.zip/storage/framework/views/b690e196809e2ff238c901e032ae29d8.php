
<?php $__env->startSection('title'); ?>
VB Salon | Laporan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('judul'); ?>
Laporan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="row">
    <div class="col-md-12">
        <a id="btn-laporan-penjualan" style="color: white" class="btn btn-success mb-3" type="button"> Laporan Penjualan</a>
        <a id="btn-laporan-pembelian" style="color: white" class="btn btn-primary mb-3" type="button"> Laporan Pembelian</a>

    </div>
</div>

<div id="laporan-penjualan-table" class="card mb-4" style="color: black">
    <div class="card-header">
        Laporan Penjualan
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('filterPenjualan')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-4">
                    <input type="date" class="form-control" name="tgl_awal" value="<?php echo e($data['tanggal']['tgl_awal']); ?>" title="Tanggal Awal">
                </div>
                <div class="col-4">
                    <input type="date" class="form-control" name="tgl_akhir" value="<?php echo e($data['tanggal']['tgl_akhir']); ?>" title="Tanggal Akhir">
                </div>
                <div class="col-4">
                    <button class="btn btn-primary">Filter</button>
                </div>
            </div>
        </form>
        <br>
        <a class="btn btn-dark mb-3" type="button" href="<?php echo e(route('penjualanExport')); ?>">
            Export Excel</a>
        <table class="dataTable table table-hover table-responsive w-auto" style="color: black">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nota</th>
                    <th>Tgl Transaksi</th>
                    <th>User</th>
                    <th>Telp Pelanggan</th>
                    <th>Total</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $data['laporan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($no++); ?></th>
                    <th style="width: 15%"><?php echo e($item->no_penjualan); ?></th>
                    <th style="width: 20%"><?php echo e(date("d/m/Y H:i:s", strtotime($item['created_at']))); ?></th>
                    <th style="width: 13%"><?php echo e($item->pegawai->nama); ?></th>
                    <th style="width: 20%"><?php echo e($item->telp_pelanggan); ?></th>
                    <th style="width: 20%">Rp <?php echo e(number_format($item->total_harga, 2, ',', '.')); ?></th>
                    <td style="width: 20%">
                        <a class="btn btn-warning text-white" href="">
                            <i class="fas fa-pen-to-square"></i> Cetak
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<div id="laporan-pembelian-table" class="card mb-4" style="color: black">
    <div class="card-header">
        Laporan Pembelian
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('filterPenjualan')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-4">
                    <input type="date" class="form-control" name="tgl_awal" value="<?php echo e($data['tanggal']['tgl_awal']); ?>" title="Tanggal Awal">
                </div>
                <div class="col-4">
                    <input type="date" class="form-control" name="tgl_akhir" value="<?php echo e($data['tanggal']['tgl_akhir']); ?>" title="Tanggal Akhir">
                </div>
                <div class="col-4">
                    <button class="btn btn-primary">Filter</button>
                </div>
            </div>
        </form>
        <br>
        <a class="btn btn-dark mb-3" type="button" href="<?php echo e(route('penjualanExport')); ?>">
            Export Excel</a>
        <table class="dataTable table table-hover table-responsive w-auto" style="color: black">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nota</th>
                    <th>Tgl Transaksi</th>
                    <th>User</th>
                    <th>Telp Pelanggan</th>
                    <th>Total</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $data['laporan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($no++); ?></th>
                    <th style="width: 15%"><?php echo e($item->no_penjualan); ?></th>
                    <th style="width: 20%"><?php echo e(date("d/m/Y H:i:s", strtotime($item['created_at']))); ?></th>
                    <th style="width: 13%"><?php echo e($item->pegawai->nama); ?></th>
                    <th style="width: 20%"><?php echo e($item->telp_pelanggan); ?></th>
                    <th style="width: 20%">Rp <?php echo e(number_format($item->total_harga, 2, ',', '.')); ?></th>
                    <td style="width: 20%">
                        <a class="btn btn-warning text-white" href="">
                            <i class="fas fa-pen-to-square"></i> Cetak
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    const btnLaporanPenjualan = document.getElementById('btn-laporan-penjualan');
    const btnLaporanPembelian = document.getElementById('btn-laporan-pembelian');

    const laporanPenjualanTable = document.getElementById('laporan-penjualan-table');
    const laporanPembelianTable = document.getElementById('laporan-pembelian-table');

    laporanPenjualanTable.style.display = 'none';
    laporanPembelianTable.style.display = 'none';

    btnLaporanPenjualan.addEventListener('click', function () {
        laporanPenjualanTable.style.display = 'block';
        laporanPembelianTable.style.display = 'none';
    });

    btnLaporanPembelian.addEventListener('click', function () {
        laporanPenjualanTable.style.display = 'none';
        laporanPembelianTable.style.display = 'block';
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 5\PADSI\PADSI_FIX\resources\views/transaksi/laporanPenjualan.blade.php ENDPATH**/ ?>