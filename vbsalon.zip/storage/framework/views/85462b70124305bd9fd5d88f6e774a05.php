
<?php $__env->startSection('title'); ?>
PADSI | LOGIN
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="login">
    <div class="logo">
        <img src="<?php echo e(asset('images/Logo.png')); ?>" class="img-fluid" alt="">
    </div>
    <form method="POST" action="<?php echo e(route('login')); ?>" class="form form-control">
        <?php echo csrf_field(); ?>
        <div class="col-lg-12 login-title">
            ADMIN PANEL
        </div>
        <?php if(Session::has('error')): ?>
        <div class="alert alert-danger" role="alert" style="text-align: center">
            <?php echo e(Session::get('error')); ?>

        </div>
        <?php endif; ?>
        <!-- Username Address -->
        <div class="form-outline mb-4">
            <label class="form-label" for="username">Username</label>
            <input class="form-control" id="username" type="text" name="username" placeholder="Masukkan username atau email" required autofocus>
        </div>

        <!-- Password -->
        <div class="form-outline mb-4">
            <label for="password">Password</label>
            <input id="password" class="form-control" type="password" name="password" placeholder="Masukkan password" required autocomplete="current-password"> 
        </div>

        <!-- Remember Me -->
        <div class="row mb-1">
            <div class="col d-flex justify-content-center">
                <div class="form-check">
                    <input id="remember_me" type="checkbox" class="form-check-input" name="remember">
                    <label for="remember_me" class="form-check-label"><?php echo e(__('Remember me')); ?></label>
                </div>
            </div>
        </div>
        <div class="d-flex align-items-center justify-content-center mt-4">
            <button class="btn btn-success" style="margin-left: 1rem; ">Login</button>
        </div>
    </form>
</div>

<style>
    .login{
        display: flex;
        flex-direction:column;
        justify-content: center;
        align-items: center;
        height: 100vh;
        background: rgb(245, 245, 245)
    }
    .login-title {
        margin-bottom: 10px;
        text-align: center;
        font-size: 30px;
        letter-spacing: 2px;
        font-weight: bold;
        color: black;
    }
    .form{
        padding: 2rem;
        max-width: 30rem;
        display: flex;flex-direction: column;
    }
    .logo{
        max-width: 20rem;
        /* margin-bottom: 5px */
    }
    .img-fluid {
        max-width: 100%;
        height: auto;
    }
    @media only screen and (max-width: 450px){
        .form{
            max-width: 25rem;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.authApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 5\PADSI\PADSI_FIX\resources\views/auth/login.blade.php ENDPATH**/ ?>