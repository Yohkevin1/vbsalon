
<?php $__env->startSection('title'); ?>
PADSI | LOGIN
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="form">
    <div class="form-box">
        <div class="form-value">
            <form method="POST" action="<?php echo e(route('searchAcc')); ?>">
                <h2>Forget Password</h2>
                <?php echo csrf_field(); ?>
                <div class="invalid-feedback">
                    <?= session('error') ?>
                </div>
                <div class="inputbox">
                    <ion-icon name="person-circle-outline"></ion-icon>
                    <input type="username" name="username" required>
                    <label for="">Username</label>
                </div>
                <button>Search</button>
            </form>
            <div class="forget">
                <label><a href="<?php echo e(route('login')); ?>">Back to Login</a></label>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.authApp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 5\PADSI\PADSI_FIX\resources\views/auth/cariAkun.blade.php ENDPATH**/ ?>