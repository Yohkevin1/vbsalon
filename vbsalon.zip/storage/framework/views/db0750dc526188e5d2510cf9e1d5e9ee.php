
<?php $__env->startSection('title'); ?>
VB Salon | Supplier
<?php $__env->stopSection(); ?>
<?php $__env->startSection('judul'); ?>
Supplier
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<div class="row">
    <div class="col-md-12">
        <div class="card mb-4" style="color: black">
            <div class="card-header">
                List Data Supplier
            </div>
            <div class="card-body">
                <a href="<?php echo e(route('supplierPage')); ?>" class="btn btn-primary mb-3 btn-tambah"><i class="fas fa-plus-circle"></i> Tambah Supplier</a>
                <table class="dataTable table table-hover table-responsive w-auto" style="color: black">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Alamat</th>
                            <th>No. Telp</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th ><?php echo e($no++); ?></th>
                                <th><?php echo e($item->nama); ?></th>
                                <th><?php echo e($item->email); ?></th>
                                <th><?php echo e(substr($item->alamat, 0, 100)); ?></th>
                                <th><?php echo e($item->telp); ?></th>
                                <td style="width: 20%">
                                    <a class="btn btn-warning text-white" href="<?php echo e(route('supplierEditPage', encrypt($item->kode_supplier))); ?>">
                                        <i class="fas fa-pen-to-square"></i> Ubah
                                    </a>
                                    <a class="btn btn-danger text-white" href="#" data-toggle="modal" data-target="#deleteModal<?php echo e($item->kode_supplier); ?>">
                                        <i class="fa-solid fa-trash"></i> Hapus
                                    </a>
                                    <a class="btn btn-secondary text-white" href="<?php echo e(route('detailPageSPL', encrypt($item->kode_supplier))); ?>">
                                        <i class="fa-solid fa-circle-info"></i> Detail
                                    </a>
                                </td>
                            </tr>
                            <!-- Delete Modal untuk Supplier Tertentu -->
                            <div class="modal fade" id="deleteModal<?php echo e($item->kode_supplier); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Yakin data dihapus?</h5>
                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">Klik "hapus" di bawah ini jika Anda yakin ingin menghapus data <?php echo e($item->nama); ?>.</div>
                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                            <a class="btn btn-primary" href="<?php echo e(route('deleteSupplier', encrypt($item->kode_supplier))); ?>">Hapus</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 5\PADSI\PADSI_FIX\resources\views/supplier/indexSupplier.blade.php ENDPATH**/ ?>