<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Email</title>
</head>
<body>
    <div>
    <p>Name: <?php echo e($data['name']); ?></p>
    <p>Email: <?php echo e($data['email']); ?></p>
    <p>Phone: <?php echo e($data['phone']); ?></p>
    <p>Message: <br><?php echo e($data['message']); ?></p>
</div>
</body>
</html><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 5\PADSI\PADSI_FIX\resources\views/sendMail.blade.php ENDPATH**/ ?>