<!DOCTYPE html>
<html>
<head>
    <title>Nota Pembelian</title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/Logo.png')); ?>">
    <style>
        .barang {
            border-collapse: collapse;
            width: 100%;
        }
        .barang th {
            font-weight: bold !important;
            border: 1px solid black;
            padding: 8px;
        }
        .barang td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        .dataPJL th {
            font-weight: bold !important;
            padding: 8px;
            text-align: left;
        }
        .dataPJL td {
            padding: 8px;
            text-align: left;
        }
    </style>
</head>
<body style="color: black;">
    <h1 style="text-align: center">VENUS BEAUTY SALON</h1>
    <p style="text-align: center">No. Pembelian: <?php echo e($data['trs']->no_pembelian); ?></p>
    <div></div>
    <table class="dataPJL">
        <thead>
            <tr>
                <th style="width: 75%">Tanggal: </th>
                <th style="width: 25%">Pegawai: </th>
            </tr>
        </thead>
        <tbody> 
            <tr>
                <td style="width: 75%"><?php echo e(date('l, d F Y, H:i:s', strtotime($data['trs']->created_at))); ?></td>
                <td style="width: 25%"><?php echo e($data['trs']->pegawai->nama); ?></td>
            </tr>
        </tbody>
    </table>
    <div></div>
    <?php if($data['produk'] != null): ?>
        <div></div>
        <table class="barang" style="color: black;">
            <thead>
                <tr>
                    <th style="width: 15%; text-align: center;">Kode Produk</th>
                    <th style="width: 15%; text-align: center;">Foto</th>
                    <th style="width: 20%; text-align: center;">Merek</th>
                    <th style="width: 50%; text-align: center;">Deskripsi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="width: 15%; text-align: left;"><?php echo e($data['produk']->kode_produk); ?></td>
                    <th style="width: 15%; text-align: left;">
                        <img src="<?php echo e(public_path('images/produk/' . $data['produk']->foto)); ?>" alt="" width="100">
                    </th>
                    <td style="width: 20%; text-align: left;"><?php echo e($data['produk']->merek); ?></td>
                    <td style="width: 50%; text-align: left;"><?php echo e($data['produk']->deskripsi); ?></td>
                </tr>
            </tbody>
        </table>
        <div></div>
        <div></div>
    <?php endif; ?>
    <table class="dataPJL">
        <thead>
            <tr>
                <th style="width: 75%">Keterangan: </th>
                <th style="width: 25%">Total Tagihan: </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="width: 75%"><span><?php echo e($data['trs']->keterangan); ?></span></td>
                <td style="width: 25%"><span><?php echo e("Rp. " . number_format($data['trs']->total_harga, 0, ',', '.')); ?></span></td>
            </tr>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 5\PADSI\PADSI_FIX\resources\views/nota/notaPBL.blade.php ENDPATH**/ ?>